untuk keterangan script ada di sini:
http://www.bayuajie.com/blog/2017/05/26/membuat-form-php-ke-email/

script ini dapat dimodifikasi untuk berbagai keperluan seperti:
- form pemesanan pada sebuah toko online
- form komplain
- form support clien
- form konfirmasi
dan sebagainya 

untuk modifikasi sesuai dengan kebutuhan anda, silahkan hubungi saya
Whatsapp: 0813 9024 1937

soal fee bisa dibicarakan, sob .. hahahaa :D
